// https://stackoverflow.com/questions/52578146/images-streamed-over-tcp-are-split-in-3-with-middle-missing/52582372#52582372

import cv2
import numpy as np
import socket
from threading import Thread

_continue = True
def imageStreamer4():
    global _continue
    cam = cv2.VideoCapture(0)
    camSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    camSocket.bind(("",8081))
    camSocket.listen(1)
    # set flip image to false if you don't want the image to be flipped
    flipImage = True

    while _continue:
        try:
            client,address = camSocket.accept()
            print("client connected")
            ret,camImage = cam.read()
            if flipImage:
                camImage = cv2.flip(camImage,1)

            #uncomment the below code to view the webcam stream locally
            """
            cv2.imshow('image',camImage)
            if cv2.waitKey(1) == 27: 
                break  # esc to quit
            """
            byteString = bytes(cv2.imencode('.jpg', camImage)[1].tostring())
            fileSize = len(byteString)
            totalSent = 0
            client.send(str(fileSize).encode())

            sizeConfirmation = client.recv(1024)

            totalSent = 0
            while totalSent < fileSize:
                totalSent += client.send(byteString[totalSent:])

            print(str(fileSize), str(totalSent),sizeConfirmation.decode('utf-8'))

        except Exception as e:
            print(e)
            print("shutting down video stream")
            _continue = False

    print("video stream exited.")