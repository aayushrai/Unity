using System.Collections;
using UnityEngine;
using System;
using System.Net;
using System.Text;
using System.Net.Sockets;
using System.Threading;
using UnityEngine.UI;
using System.IO;

void getVideoStream()
    {
        byte[] header; 
        int recieved;
        int fileSize;
        NetworkStream dataStream;
        MemoryStream ms;
        while (connectCam)
        {
            fileSize = 0;
            recieved = 0;
            camClient = new TcpClient(camIP, camPort);

            //get header
            dataStream = camClient.GetStream();
            while (!dataStream.DataAvailable)
            {
                //waste time
            }
            header = new byte[1024];
            dataStream.Read(header, 0, header.Length);
            fileSize = Int32.Parse(Encoding.Default.GetString(bytesReducer(header)));
            byte[] result = Encoding.ASCII.GetBytes(fileSize.ToString());

            //send response
            dataStream.Write(result, 0, result.Length);

            ms = new MemoryStream();
            while (!dataStream.DataAvailable)
            {
                //waste time
            }
            while (recieved < fileSize)
            {
                byte[] data = new byte[camClient.ReceiveBufferSize];
                recieved += dataStream.Read(data, 0, data.Length);
                ms.Write(data, 0, data.Length);

            }
            //the below class simply sends function calls from secondary thread back to the main thread
            UnityMainThreadDispatcher.Instance().Enqueue(convertBytesToTexture(ms.ToArray()));
            dataStream.Close();
            camClient.Close();

        }
    }

void convertBytesToTexture(byte[] byteArray) {
        try
        {
            camTexture.LoadImage(byteArray); //Texture2D object
            camImage.texture = camTexture; //RawImage object
        }
        catch (Exception e)
        {
            print(e);
        }
    }