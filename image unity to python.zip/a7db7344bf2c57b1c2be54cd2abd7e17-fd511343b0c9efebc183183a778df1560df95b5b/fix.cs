// fix
int increment = 0;
while (recieved < fileSize)
{
     byte[] data = new byte[camClient.ReceiveBufferSize];
     increment = dataStream.Read(data, 0, data.Length);
     recieved += increment; 
     ms.Write(data.Take(increment).ToArray(), 0, increment);

}